def o_que_o_gato_faz():
    print("arranha")

def o_que_o_cachorro_faz():
    print("au au")

