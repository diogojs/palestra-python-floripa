def o_que_o_gato_faz():
    print("miau")

