# Example Package

This is a simple example package for a python lecture about Dependencies Management.
It only contains some very simple functions that print some data.
